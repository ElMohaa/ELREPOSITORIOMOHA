package org.example.next_goat.Clases;


import java.util.List;

public class CompetitionsResponse {
    private int count;
    private List<Competition> competitions;

    public int getCount() {
        return count;
    }

    public List<Competition> getCompetitions() {
        return competitions;
    }
}
