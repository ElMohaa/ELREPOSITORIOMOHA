package org.example.next_goat.Controllers;

public class WaitController {
}
