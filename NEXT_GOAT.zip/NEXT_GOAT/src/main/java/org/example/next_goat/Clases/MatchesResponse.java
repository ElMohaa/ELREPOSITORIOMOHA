package org.example.next_goat.Clases;

import java.util.List;

public class MatchesResponse {
    private List<Match> matches; // Suponiendo que hay una clase Match para representar un partido.

    public List<Match> getMatches() {
        return matches;
    }
}
