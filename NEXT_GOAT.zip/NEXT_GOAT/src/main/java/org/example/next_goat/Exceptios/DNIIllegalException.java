package org.example.next_goat.Exceptios;

public class DNIIllegalException extends Exception {
    public DNIIllegalException() {
        super();
    }
    public DNIIllegalException(String mensaje) {
        super(mensaje);
    }
}
